// import React from 'react';
// import './navbar.scss';
// import { motion } from 'framer-motion';
// import Sidebar from '../sidebar/Sidebar';
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faDownload } from "@fortawesome/free-solid-svg-icons";

// const variants={
//   initial:{
//     x:-500,
//     y:0,
//     opacity:0,
//   },
//   animate:{
//     x:0,
//     y:0,
//     opacity:1,
//     transition:{
//       duration:1,
//       staggerChildren:0.1,
//     },
//   },
// };

// const Navbar = () => {
//   return (
//     <div className="navbar">
//       <Sidebar />
//       <div className="wrapper">
//         <motion.span whileHover={{ color: 'orange' }}> NEELESH </motion.span>
//         <motion.div className="social" variants={variants} initial="initial" animate="animate">
//           <motion.button whileHover={{backgroundColor:"orange"}}><a href="#">Download My Resume <FontAwesomeIcon icon={faDownload} /></a></motion.button>
//         </motion.div>
//       </div>
//     </div>
//   );
// };

// export default Navbar;


import React from 'react';
import './navbar.scss';
import { motion } from 'framer-motion';
import Sidebar from '../sidebar/Sidebar';
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faDownload } from "@fortawesome/free-solid-svg-icons";

const Navbar = () => {
  return (
    <div className="navbar">
      <Sidebar />
      <div className="wrapper">
        <motion.span whileHover={{ color: 'orange' }}> MY PORTFOLIO </motion.span>
        {/* <div className="social">
          <button>
            <a href="https://fontawesome.com/docs/web/use-with/react/add-icons#add-icons-globally" style={{cursor:'pointer'}}><FontAwesomeIcon icon={faDownload}/></a>
          </button>
        </div> */}
      </div>
    </div>
  );
};

export default Navbar;
