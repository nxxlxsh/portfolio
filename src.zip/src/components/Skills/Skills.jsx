import './skills.scss';
import {motion} from 'framer-motion';

const variants={
  initial:{
    x:1000,
    y:0,
    opacity:0,
  },
  animate:{
    x:0,
    y:0,
    opacity:1,
    transition:{
      duration:1,
      staggerChildren:0.1,
    },
  },
};

const Skills=()=>{
  
  return (
    <motion.div className='skills' variants={variants} initial="initial" whileInView="animate">
        <motion.div className="titleContainer" variants={variants}>
          <div className="title">
            <img src="/skills.jpeg" alt="" />
            <h1><motion.b whileHover={{color:"orange"}}>What I</motion.b></h1>
          </div>
          <div className="title">
            <h1><motion.b whileHover={{color:"orange"}}></motion.b> Know ?</h1>
            <button>My Skills</button>
          </div>
        </motion.div>
        <motion.div className="listContainer" variants={variants}>
            <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>
              <p>
                <img src="/skills/c.png" alt="" className='work' />
              </p>
            </motion.div>
            <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>
              <p>
                <img src="/skills/cpp.png" alt="" className='work' />
              </p>
            </motion.div>
            <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>
              <p>
                <img src="/skills/html.png" alt="" className='work' />
              </p>
            </motion.div>
            <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>
              <p>
                <img src="/skills/css.png" alt="" className='work' />
              </p>
            </motion.div>
            <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>
              <p>
                <img src="/skills/js.png" alt="" className='work' />
              </p>
            </motion.div>
            <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>
              <p>
                <img src="/skills/sass.png" alt="" className='work' />
              </p>
            </motion.div>
            <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>
              <p>
                <img src="/skills/bootstrap.png" alt="" className='work' />
              </p>
            </motion.div>
            <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>
              <p>
                <img src="/skills/jquery.png" alt="" className='work' />
              </p>
            </motion.div>
            <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>
              <p>
                <img src="/skills/node.png" alt="" className='work' />
              </p>
            </motion.div>
            <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>
              <p>
                <img src="/skills/react.png" alt="" className='work' />
              </p>
            </motion.div>
        </motion.div>
    </motion.div>
  );
};

export default Skills;

// 01:22 Lama Dev