import React from 'react';
import './About.scss';
import {motion} from 'framer-motion';

const variants={
  initial:{
    x:0,
    y:0,
    opacity:0,
  },
  animate:{
    x:0,
    y:0,
    opacity:1,
    transition:{
      duration:1,
      staggerChildren:0.1,
    },
  },
};

const About = () => {
  return (
    <div className="about-section">
      <motion.div className="about-content" variants={variants} initial="initial" whileInView="animate">
        <motion.h2 
          variants={variants}
          initial={{opacity:0}} 
          whileInView={{opacity:1}} 
          transition={{delay:3,duration:1}}>About Me</motion.h2>
        <motion.p
          variants={variants} 
          initial={{opacity:0}} 
          whileInView={{opacity:1}} 
          transition={{delay:4,duration:1}}>
        A Passionate Web Development and Coding Enthusiast who brings Fresh Perspectives and a Hunger for Learning, I am adept at turning ideas into fully functional and visually appealing websites.
        </motion.p>
        <motion.p
          variants={variants} 
          initial={{opacity:0}} 
          whileInView={{opacity:1}} 
          transition={{delay:5,duration:1}}>
        Excited about the Prospect of Contributing my Skills and Enthusiasm to Innovative Projects and Open to Exploring new Opportunities in the Dynamic field of Web Development.
        </motion.p>
        <motion.p 
          variants={variants} 
          initial={{opacity:0}} 
          whileInView={{opacity:1}} 
          transition={{delay:6,duration:1}}>Let's connect and explore the possibilities together!
        </motion.p>
        <motion.div variants={variants} initial="initial" whileInView="animate" className="social">
              <a href="https://www.facebook.com/neelesh.kumar4545"><img src="\facebook.png" /></a>
              <a href="https://www.instagram.com/dkwnstranger/"><img src="\instagram.png" /></a>
              <a href="https://www.linkedin.com/in/neeleshk19/"><img src="\linkedin.png" /></a>
              <a href="https://leetcode.com/nxxlxsh/"><img src="\leetcode.png" /></a>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default About;
