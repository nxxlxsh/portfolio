import './services.scss';
import {motion} from 'framer-motion';

const variants={
  initial:{
    x:-500,
    y:0,
    opacity:0,
  },
  animate:{
    x:0,
    y:0,
    opacity:1,
    transition:{
      duration:1,
      staggerChildren:0.1,
    },
  },
};

const Services=()=>{

  
  return (
    <motion.div className='services' variants={variants} initial="initial" whileInView="animate">
        <motion.div className="titleContainer" variants={variants}>
          <div className="title">
            <img src="/qual.jpg" alt="" />
            <h1><motion.b whileHover={{color:"orange"}}>What I</motion.b></h1>
          </div>
          <div className="title">
            <h1><motion.b whileHover={{color:"orange"}}>Have</motion.b> Done ?</h1>
            <button>My Qualifications</button>
          </div>
        </motion.div>
        <motion.div className="listContainer" variants={variants}>
          <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>
            <h2>MTech</h2>
            <p>
              <img src="/iitk.jpeg" alt="" className='institute'/>
              <h5>Power Engineering<br/>2023-2024<br/>CPI- 8.11/10</h5>
            </p>
            <button><a href="https://drive.google.com/file/d/1y7OxeR_OhTEVJ_YEIw6Go16VfaMRJDg7/view?usp=sharing" alt="">Go</a></button>
          </motion.div>
          <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>          
            <h2>BTech</h2>
            <p>
              <img src="/mnnit.png" alt="" className='institute'/>
              <h5>Electrical Engineering<br/>2017-2021<br/>CPI- 8.44/10</h5>
            </p>
            <button><a href="https://drive.google.com/file/d/137bFJUsTLNRrO3j3D9bhU_Ok2YFlCvlY/view?usp=sharing" alt="">Go</a></button>
          </motion.div>
          <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>          
            <h2>Class XII</h2>
            <p>
              <img src="/swcjhs1.jpg" alt="" className='institute'/>
              <h5><br/>2015-2016<br/>Percentage- 92.4%</h5>
            </p>
            <button><a href="https://drive.google.com/file/d/1vKYLMNbuCT1kSas2M6Pw5-0SWUFPqniU/view?usp=sharing" alt="">Go</a></button>
          </motion.div>
          <motion.div className='box' whileHover={{background:"lightgray", color:"black"}}>          
            <h2>Class X</h2>
            <p>
              <img src="/swcjhs1.jpg" alt="" className='institute'/>
              <h5><br/>2013-2014<br/>CPI- 9.2/10</h5>
            </p>
            <button><a href="https://drive.google.com/file/d/1aPDUCNGVhaPcmCtJ4cA6tmF8x_SvJRHf/view?usp=sharing" alt="">Go</a></button>
          </motion.div>
        </motion.div>

    </motion.div>
  );
};

export default Services;

// 01:22 Lama Dev